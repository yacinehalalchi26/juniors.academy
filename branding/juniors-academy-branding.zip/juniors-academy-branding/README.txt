JUNIORS ACADEMY — BRAND BOOK (web page)
Version 1.0 · September 2026

TO PUT IT LIVE AT juniors.academy/branding

  1. Upload this whole folder's CONTENTS to /branding/ on the server:
       /branding/index.html
       /branding/img/...        (keep the folder structure exactly)
  2. Open https://juniors.academy/branding — index.html is served automatically.
  3. Nothing else is needed. No build step, no database, no plugin.

WHAT IT NEEDS
  An internet connection for the two typefaces, which load from Google Fonts
  (Poppins and Cairo). Everything else — the CSS, the JavaScript, the images —
  is inside this folder. The page works on a phone and follows the reader's
  light or dark setting.

  The page carries <meta name="robots" content="noindex">, so Google will not
  list it. It is reachable by anyone who has the address. Remove that line if
  you ever want it indexed, and put it behind a password if you want it private.

EDITING IT LATER
  index.html is a single file. Text, tables and captions are plain HTML near
  the parts they describe; the styles sit in one <style> block at the top.
  Change the version line in the header whenever the content changes.

FOLDERS
  img/logo/     the logo lock-ups shown on the page
  img/av/       the six profile-mark treatments and the comparison sheet
  img/rules/    the twelve do-and-don't panels
  img/tpl/      the eight core templates
  img/series/   the ten weekly series formats
  img/more/     the eighteen occasional formats
  img/gaps/     four more formats
  img/red/      the red-led comparison set
  img/grid.jpg, img/carousel.jpg, img/ja-brand-palette.png

NOTE
  Every price, date, ratio, name and quote inside the template images is a
  placeholder. The full-resolution source files are in the brand kit, not here —
  this folder holds web-sized copies for the page only.
